# JARVIS AI — Android source project (v2)

This ZIP contains an Android Studio source project. It is not a compiled APK and has not been built/tested on the user's device.

## Implemented in this source
- Red/black Android Compose interface
- JARVIS and NOVA character selector (stylized 2D initials, not real 3D models)
- Tap-to-speak Hindi voice input using Android speech recognition
- Text-to-speech using the device's installed voice/language support
- Basic local commands: time/date, YouTube, WhatsApp launch, Settings, dialer, clock app
- Simple in-app PIN gate (demo-level app lock; not device lock or secure biometric authentication)
- Optional notification-listener service declaration, intentionally does not collect notification content

## Not implemented / Android limitations
- Real AI model/backend, long-term AI memory, cloud sync
- Real 3D animated male/female avatars
- Reliable voice biometric owner verification
- WhatsApp notification reading and sending/reply automation
- Detecting failed lock-screen PIN attempts, covert selfie capture, or locking the whole phone
- Guaranteed deep female voice (voice availability depends on Android TTS engines and installed voice data)

Normal Android apps cannot reliably observe failed device-lock attempts or replace the system lock screen. Do not use hidden camera/microphone capture. WhatsApp automation must be transparent, user-authorized, and confirmed before sending.

## Build
Open this folder in Android Studio with Android SDK 36 installed. Sync Gradle, then Build > Build APK(s). Install only on a device you own or have permission to test. Review permissions before enabling them.

## AI backend security
For a real AI model, create a backend service and keep provider API keys on the server. Never commit API keys, passwords, or private tokens into a public GitHub repository or mobile APK.
