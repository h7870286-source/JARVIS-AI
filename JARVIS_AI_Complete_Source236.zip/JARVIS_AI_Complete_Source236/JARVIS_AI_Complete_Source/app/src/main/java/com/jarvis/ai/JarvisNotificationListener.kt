package com.jarvis.ai

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Notification access is optional and must be enabled manually by the device owner.
 * This starter intentionally does not save, upload, or read notification contents.
 * A future notification-reading feature should disclose exactly what is read and
 * let the user choose which apps are included.
 */
class JarvisNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        // No background collection by design.
    }
}
