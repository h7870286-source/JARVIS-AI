package com.jarvis.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Black = Color(0xFF08090C)
private val Panel = Color(0xFF17191F)
private val Red = Color(0xFFE53935)
private val White = Color(0xFFF4F4F5)
private data class ChatLine(val who: String, val message: String)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { JarvisApp(::speak) }
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED)
                tts?.setLanguage(Locale.US)
        }
    }
    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply") }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun JarvisApp(speak: (String) -> Unit) {
    val context = LocalContext.current
    var pinEntry by remember { mutableStateOf("") }
    var savedPin by remember { mutableStateOf("") }
    var unlocked by remember { mutableStateOf(false) }
    var pinError by remember { mutableStateOf("") }
    var avatar by remember { mutableStateOf("JARVIS") }
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("SYSTEM READY • TAP MIC TO SPEAK") }
    var lines by remember { mutableStateOf(listOf(ChatLine("JARVIS", "Namaste! Main JARVIS hoon. Aap Hindi ya English mein baat kar sakte hain."))) }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) status = "MIC PERMISSION DENIED"
        else status = "MIC READY • TAP MIC AGAIN"
    }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val phrase = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!phrase.isNullOrBlank()) input = phrase
        status = if (phrase.isNullOrBlank()) "VOICE NOT RECOGNIZED" else "VOICE INPUT RECEIVED"
    }

    fun launchSpeech() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            status = "NO SPEECH RECOGNIZER AVAILABLE"; return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS ko command dein")
        }
        speechLauncher.launch(intent)
    }

    fun handleCommand(raw: String) {
        if (raw.isBlank()) return
        lines = lines + ChatLine("YOU", raw)
        val q = raw.lowercase(Locale.getDefault())
        val answer = when {
            q.contains("hello") || q.contains("namaste") || q.contains("नमस्ते") ->
                "Namaste! Main aapki madad ke liye taiyar hoon."
            q.contains("time") || q.contains("समय") ->
                "Abhi ${SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())} baj rahe hain."
            q.contains("date") || q.contains("तारीख") ->
                "Aaj ${SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date())} hai."
            q.contains("youtube") ->
                "YouTube khol raha hoon.".also {
                    val i = context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                        ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com"))
                    context.startActivity(i)
                }
            q.contains("whatsapp") ->
                "WhatsApp khol raha hoon. Message bhejne se pehle khud review karein.".also {
                    val i = context.packageManager.getLaunchIntentForPackage("com.whatsapp")
                        ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://whatsapp.com"))
                    context.startActivity(i)
                }
            q.contains("settings") || q.contains("सेटिंग") ->
                "Phone settings khol raha hoon.".also { context.startActivity(Intent(Settings.ACTION_SETTINGS)) }
            q.contains("call") || q.contains("कॉल") ->
                "Dialer khol raha hoon. Number check karke call aap khud karein.".also {
                    context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:")))
                }
            q.contains("alarm") || q.contains("अलार्म") ->
                "Clock app kholne ki koshish kar raha hoon.".also {
                    val i = context.packageManager.getLaunchIntentForPackage("com.google.android.deskclock")
                        ?: Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CLOCK)
                    runCatching { context.startActivity(i) }
                }
            q.contains("security") || q.contains("सिक्योरिटी") ->
                "Security section mein app PIN aur privacy controls available hain. Android lock-screen intrusion detection normal apps ko available nahi karta."
            else ->
                "Main abhi local command mode mein hoon. General AI chat aur memory ke liye secure backend connect karna zaroori hai."
        }
        lines = lines + ChatLine(avatar, answer)
        speak(answer)
        input = ""
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Black, surface = Panel,
        onPrimary = White, onBackground = White, onSurface = White)) {
        if (!unlocked) {
            PinGate(pinEntry, { pinEntry = it }, savedPin.isNotBlank(),
                { unlocked = true },
                { candidate ->
                    if (savedPin.isBlank()) { savedPin = candidate; unlocked = true; pinEntry = ""; pinError = "" }
                    else if (candidate == savedPin) { unlocked = true; pinEntry = ""; pinError = "" }
                    else { pinEntry = ""; pinError = "Incorrect PIN. Try again." }
                }, pinError)
        } else {
            Scaffold(containerColor = Black, topBar = {
                TopAppBar(
                    title = { Column {
                        Text("JARVIS AI", color = Red, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                        Text(status, color = Color.LightGray, fontSize = 10.sp)
                    } },
                    actions = { IconButton(onClick = { context.startActivity(Intent(Settings.ACTION_SETTINGS)) }) {
                        Icon(Icons.Default.Settings, contentDescription = "Phone settings", tint = White)
                    } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Black)
                )
            }) { pad ->
                Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)) {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                AvatarChoice("JARVIS", avatar == "JARVIS") { avatar = "JARVIS" }
                                AvatarChoice("NOVA", avatar == "NOVA") { avatar = "NOVA" }
                            }
                            Spacer(Modifier.height(12.dp))
                            Box(Modifier.size(104.dp).border(2.dp, Red, CircleShape)
                                .background(Color(0xFF301416), CircleShape), contentAlignment = Alignment.Center) {
                                Text(if (avatar == "NOVA") "N" else "J", color = Red, fontSize = 58.sp, fontWeight = FontWeight.Black)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(if (avatar == "NOVA") "NOVA • FEMALE VOICE OPTION" else "JARVIS • MALE ASSISTANT", color = White, fontWeight = FontWeight.Bold)
                            Text("Hindi • English • Voice Commands", color = Color.LightGray, fontSize = 12.sp)
                            Spacer(Modifier.height(10.dp))
                            Button(onClick = { launchSpeech() }, colors = ButtonDefaults.buttonColors(containerColor = Red),
                                shape = CircleShape) {
                                Icon(Icons.Default.Mic, contentDescription = null)
                                Spacer(Modifier.width(8.dp)); Text("TAP TO SPEAK")
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, tint = Red, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("SECURITY & PRIVACY", color = Red, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { unlocked = false }) {
                            Icon(Icons.Default.Lock, contentDescription = null); Text("Lock app")
                        }
                    }
                    Text("App PIN protects this JARVIS screen only. It does not replace your phone's screen lock.", color = Color.LightGray, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        items(lines) { line ->
                            Card(colors = CardDefaults.cardColors(containerColor = if (line.who == "YOU") Color(0xFF252A34) else Panel)) {
                                Column(Modifier.fillMaxWidth().padding(10.dp)) {
                                    Text(line.who, color = Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text(line.message, color = White)
                                }
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = input, onValueChange = { input = it },
                            modifier = Modifier.weight(1f), placeholder = { Text("Type a command...") },
                            shape = RoundedCornerShape(18.dp), singleLine = true)
                        Spacer(Modifier.width(6.dp))
                        IconButton(onClick = { handleCommand(input) }) {
                            Icon(Icons.Default.Send, contentDescription = "Send", tint = Red)
                        }
                    }
                    Text("Mic starts only after tap • No hidden recording or camera capture", color = Color.Gray, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun AvatarChoice(name: String, selected: Boolean, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) Red else Color.Gray)) {
        Text(name, color = if (selected) Red else White)
    }
}

@Composable
private fun PinGate(pin: String, onPin: (String) -> Unit, alreadySet: Boolean,
                    onInitialUnlock: () -> Unit, onSubmit: (String) -> Unit, error: String) {
    var confirm by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Black).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.Lock, tint = Red, modifier = Modifier.size(54.dp), contentDescription = null)
        Spacer(Modifier.height(12.dp))
        Text("JARVIS APP LOCK", color = Red, fontSize = 22.sp, fontWeight = FontWeight.Black)
        Text(if (alreadySet) "Enter your app PIN" else "Create a 4–8 digit app PIN", color = White)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(value = pin, onValueChange = { if (it.length <= 8 && it.all(Char::isDigit)) onPin(it) },
            label = { Text("PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = PasswordVisualTransformation(), singleLine = true)
        if (error.isNotBlank()) Text(error, color = Red)
        Spacer(Modifier.height(12.dp))
        Button(onClick = { if (pin.length in 4..8) onSubmit(pin) },
            enabled = pin.length in 4..8, colors = ButtonDefaults.buttonColors(containerColor = Red)) {
            Text(if (alreadySet) "UNLOCK" else "SET PIN & CONTINUE")
        }
        Text("Demo app lock only; use Android screen lock for device security.", color = Color.Gray, fontSize = 10.sp)
    }
}
